#' Sparse Tree-Aggregation Regression: Simple and Post-Estimation
#'
#' Fits the sparse tree-aggregation regression model at a specific pair of penalty parameters (\code{lambda1}, \code{lambda2})
#' via the ADMM solver, with optional post-estimation (group-based OLS debiasing) for enhanced inference.
#'
#' @param X Predictor matrix (n x p).
#' @param y Response vector (length n).
#' @param P_list List specifying the number of nodes at each tree level.
#' @param Ki_list List specifying group sizes at each tree level.
#' @param post Logical; if \code{TRUE} (default), returns the post-estimated ("debiased") coefficient vector via post-OLS (recommended for inference). If \code{FALSE}, returns the direct LA-ADMM solution ("simple" estimation).
#' @param lambda1 Optional numeric vector of aggregation penalty (\eqn{\lambda_1}) values. If \code{NULL}, generated automatically.
#' @param lambda2 Optional numeric vector of sparsity penalty (\eqn{\lambda_2}) values. If \code{NULL}, generated automatically.
#' @param num_lambdas Number of grid points for each penalty dimension if grids are auto-generated. Default is 10.
#' @param rho ADMM penalty parameter (default: 1).
#' @param K_in Number of ADMM iterations (default: 1000).
#' @param stop_thresh Threshold to stop the iterations once convergence gas been achieved (depends on the scae of the data) (default: 1e-05).
#' @param standardize If TRUE: the function standardizes the data, if FALSE, then the function keeps X and y as is
#' @param lambda_min_ratio Ratio to multiply to lambda_max to define the minimum value of the grid
#' @param lambda_min Minimum value of the grid
#' @param b2_final If TRUE: returns the beta^2 copy instead of the average of the copies for beta. Default is FALSE.
#'
#' @details
#' This function fits the sparse tree-aggregation regression model for the provided penalty pair.
#' If \code{post = TRUE}, it performs group-based ordinary least squares post-estimation (debiasing) based on the penalized estimate, for potentially improved statistical inference.
#' If \code{post = FALSE}, it returns the penalized LA-ADMM coefficients as is.
#'
#' The penalty types are automatically set to \emph{node sparsity} and \emph{leaf sparsity}.
#'
#' @return A list with elements:
#'   \describe{
#'     \item{beta}{Estimated coefficient matrix (column vector if single penalty pair; can have multiple columns if called with vectors). If \code{post=TRUE}, this is the post-OLS/debiased estimate.}
#'     \item{gamma}{Estimated node parameters (from LA-ADMM; unchanged by post-processing).}
#'     \item{lambda1}{Grid of lambda1 used for the estimation.}
#'     \item{lambda2}{Grid of lambda2 used for the estimation.}
#'     \item{iterations}{number of iterations per grid result}
#'   }
#'
#' @export
startime <- function(X, y, P_list, Ki_list, post = TRUE, lambda1 = NULL,
                     lambda2 = NULL,num_lambdas = 10,
                     rho = 1, K_in = 1000, stop_thresh=1e-05, standardize = FALSE,
                     lambda_min_ratio = NULL, lambda_min = NULL, b2_final = FALSE) {

  if (standardize == TRUE){
    # Center the predictors and response
    y <- y - mean(y)
    # Standardize the predictors
    X <- scale(X)
  }

  X <- as.matrix(X)
  y <- as.numeric(y)

  stopifnot(nrow(X) == length(y))

  A <- create_matrix_A(P_list, Ki_list)
  sp_Astar <- create_matrix_A_star(P_list, Ki_list)

  b_init <- rep(0, sum_first_elements(P_list))
  g_init <- rep(0, sum_all_elements(P_list))

  # Auto-generate lambda grids if not provided
  if (is.null(lambda1)) {
    cat("lambda1 generated\n")
    lambda1 <- lambda_grid(X, y, num_lambdas, penalty = "node sparsity", A = A,
                            sp_Astar = sp_Astar,
                           lambda_min_ratio = lambda_min_ratio,
                           lambda_min = lambda_min)
  }

  if (is.null(lambda2)) {
    cat("lambda2 generated\n")
    lambda2 <- lambda_grid(X, y, num_lambdas, penalty = "leaf sparsity", A = A,
                           sp_Astar = sp_Astar,
                           lambda_min_ratio = lambda_min_ratio,
                           lambda_min = lambda_min)
  }

  beta_grid <- admm_grid(X, y, lambda1, lambda2,
                         rho, K_in,stop_thresh, P_list, Ki_list,
                         b_init,g_init)


  if (post == TRUE){
    # Run post-estimation
    post <- post_estimation(X, y, beta_grid, A,P_list)
    beta_final <- post$beta_matrix
    gamma_final <- beta_grid$gamma_matrix # There is no post gamma, so we keep the original one
  } else {
    # Keep the simple estimation
    if (!b2_final){
      beta_final <- beta_grid$beta_matrix
    } else {
      beta_final <- beta_grid$beta2_matrix
    }
    gamma_final <- beta_grid$gamma_matrix
  }

  return(list(beta = beta_final, gamma = gamma_final,
              lambda1 = lambda1,
              lambda2 = lambda2,
              iterations = beta_grid$n_iter_matrix))
}



#' Sparse Tree-Aggregation Estimation with Automatic IC-Based Tuning
#'
#' Runs the ADMM solver over a grid of aggregation (\code{lambda1}) and sparsity (\code{lambda2}) penalty values,
#' computes an information criterion (IC) for each pair, and selects the best hyperparameters based on the minimum IC.
#' Lambda grids are automatically generated if not provided.
#'
#' @param X Numeric predictor matrix (\eqn{n \times p}).
#' @param y Numeric response vector of length \eqn{n}.
#' @param P_list List specifying the number of nodes at each tree level.
#' @param Ki_list List specifying group sizes at each tree level.
#' @param post Logical; if \code{TRUE} (default), returns the post-estimated ("debiased") coefficient vector via post-OLS (recommended for inference). If \code{FALSE}, returns the direct LA-ADMM solution ("simple" estimation).
#' @param lambda1_grid Optional numeric vector of aggregation penalty (\eqn{\lambda_1}) values. If \code{NULL}, generated automatically.
#' @param lambda2_grid Optional numeric vector of sparsity penalty (\eqn{\lambda_2}) values. If \code{NULL}, generated automatically.
#' @param num_lambdas Number of grid points for each penalty dimension if grids are auto-generated. Default is 10.
#' @param rho ADMM penalty parameter (\eqn{\rho}). Default is 1.
#' @param K_in Number of inner ADMM iterations per outer iteration. Default is 100.
#' @param stop_thresh Threshold to stop the iterations once convergence gas been achieved (depends on the scae of the data) (default: 1e-05).
#' @param ic_type Information criterion type for tuning ("BIC", "AIC", etc.). Passed to \code{ic_deriv}.
#' @param thresh Threshold parameter for IC calculation (see \code{ic_deriv} documentation).
#' @param standardize If TRUE: the function standardizes the data, if FALSE, then the function keeps X and y as is
#' @param lambda_min_ratio Ratio to multiply to lambda_max to define the minimum value of the grid
#' @param lambda_min Minimum value of the grid
#' @param b2_final If TRUE: returns the beta^2 copy instead of the average of the copies for beta. Default is FALSE.
#'
#' @details
#' For each \code{(lambda1, lambda2)} pair, fits the ADMM estimator, computes the IC (using the provided \code{compute_ic} function),
#' and chooses the pair minimizing the IC. The optimal coefficients and lambda values are returned.
#'
#' Penalty types are fixed as "node sparsity" for aggregation penalty and "leaf sparsity" for sparsity penalty.
#'
#' @return A list with the following components:
#'   \describe{
#'     \item{beta}{Estimated regression coefficients (\eqn{p}-vector) for the selected penalty pair.}
#'     \item{gamma}{Estimated node parameters (\eqn{g}-vector) for the selected penalty pair.}
#'     \item{lambda1_best}{Selected \eqn{\lambda_1} (aggregation) penalty value.}
#'     \item{lambda2_best}{Selected \eqn{\lambda_2} (sparsity) penalty value.}
#'     \item{lambda1}{Grid of lambda1 used for the estimation.}
#'     \item{lambda2}{Grid of lambda2 used for the estimation.}
#'     \item{ic}{Minimum IC computed.}
#'     \item{ic_values}{All ic values computed for the lambdas combinations.}
#'     \item{iterations}{number of iterations per grid result}
#'   }
#'
#' @export
startime_ic <- function(X, y, P_list, Ki_list, post = TRUE,
                        lambda1_grid = NULL, lambda2_grid = NULL,
                        num_lambdas = 10,
                        rho = 1,
                        K_in = 100, stop_thresh=1e-05,
                        ic_type = "BIC",
                        thresh = 1,
                        standardize = FALSE,
                        lambda_min_ratio = NULL, lambda_min = NULL,
                        b2_final = FALSE) {

  if (standardize == TRUE){
    # Center the predictors and response
    y <- y - mean(y)
    # Standardize the predictors
    X <- scale(X)
  }

  X <- as.matrix(X)
  y <- as.numeric(y)
  n <- nrow(X)
  p <- ncol(X)
  stopifnot(length(y) == n)

  A <- create_matrix_A(P_list, Ki_list)
  sp_Astar <- create_matrix_A_star(P_list, Ki_list)

  # Hardcoded penalties
  leaf_penalty <- "leaf sparsity"
  node_penalty <- "node sparsity"

  b_init <- rep(0, sum_first_elements(P_list))
  g_init <- rep(0, sum_all_elements(P_list))

  # Auto-generate lambda grids if not provided
  if (is.null(lambda1_grid)) {
    cat("lambda1_grid generated\n")
    lambda1_grid <- lambda_grid(X, y, num_lambdas, penalty = node_penalty, A = A,
                                 sp_Astar = sp_Astar,
                                lambda_min_ratio = lambda_min_ratio,
                                lambda_min = lambda_min)
  }

  if (is.null(lambda2_grid)) {
    cat("lambda2_grid generated\n")
    lambda2_grid <- lambda_grid(X, y, num_lambdas, penalty = leaf_penalty, A = A,
                                sp_Astar = sp_Astar,
                                lambda_min_ratio = lambda_min_ratio,
                                lambda_min = lambda_min)
  }

  beta_grid <- admm_grid(X, y, lambda1_grid, lambda2_grid,
                         rho, K_in,stop_thresh, P_list, Ki_list,
                         b_init,g_init)


  if (post == TRUE){
    # Post-processing
    post_beta <-  post_estimation(X, y, beta_grid, A, P_list)

    # (Post) IC selection
    ic_post <-  ic_select_post(X, y, post_beta, ic_type, thresh)
    ic_values <- ic_post$values

    ic_min <- ic_post$min_ic

    beta_best <- post_beta$beta_matrix[, ic_post$best_row]
    gamma_best <- beta_grid$gamma_matrix[,ic_post$best_row] # There is no post gamma, so we keep the original one

    lambda1_best <- ic_post$best_lambda1
    lambda2_best <- ic_post$best_lambda2
  } else {
    # Compute IC for every grid value
    ic <- ic_select_apply(X, y, A, beta_grid, ic_type, thresh)

    ic_values <- ic$values

    index_min_ic <- which.min(ic$values)
    ic_min <- min(ic$values)

    if (!b2_final){
      beta_best <- beta_grid$beta_matrix[, index_min_ic]
    }
    else {
      beta_best <- beta_grid$beta2_matrix[, index_min_ic]
    }

    gamma_best <- beta_grid$gamma_matrix[, index_min_ic]

    lambda1_best <- ic$best_lambda1
    lambda2_best <- ic$best_lambda2
  }

  return(list(
    beta = beta_best,
    gamma = gamma_best,
    lambda1_best = lambda1_best,
    lambda2_best = lambda2_best,
    lambda1 = lambda1_grid,
    lambda2 = lambda2_grid,
    ic = ic_min,
    ic_values = ic_values,
    iterations = beta_grid$n_iter_matrix
  ))
}

#' Sparse Tree-Aggregation Oracle Estimation with Optional Post-Estimation (Oracle Tuning)
#'
#' Runs the ADMM solver over a grid of aggregation (\code{lambda1}) and sparsity (\code{lambda2}) penalty values,
#' computes the mean squared error (MSE) versus the true coefficients,
#' and selects the best tuning parameters based on the lowest MSE.
#' Lambda grids are automatically generated if not provided.
#' Optionally performs post-estimation (group-based OLS debiasing) on the fitted grid before oracle selection.
#'
#' @param X Numeric predictor matrix (\eqn{n \times p}).
#' @param y Numeric response vector of length \eqn{n}.
#' @param P_list List specifying the number of nodes at each tree level.
#' @param Ki_list List specifying group sizes at each tree level.
#' @param post Logical; if \code{TRUE} (default), returns the post-estimated ("debiased") coefficient vector via post-OLS (recommended for inference). If \code{FALSE}, returns the direct LA-ADMM solution ("simple" estimation).
#' @param true_beta Numeric vector of true regression coefficients (for oracle selection).
#' @param lambda1_grid Optional numeric vector of aggregation penalty (\eqn{\lambda_1}) values. If \code{NULL}, generated internally.
#' @param lambda2_grid Optional numeric vector of sparsity penalty (\eqn{\lambda_2}) values. If \code{NULL}, generated internally.
#' @param num_lambdas Number of grid points per penalty dimension if grids are auto-generated. Default is 10.
#' @param rho ADMM penalty parameter (\eqn{\rho}). Default is 1.
#' @param K_in Number of inner ADMM iterations per outer iteration. Default is 100.
#' @param stop_thresh Threshold to stop the iterations once convergence gas been achieved (depends on the scae of the data) (default: 1e-05).
#' @param standardize If TRUE: the function standardizes the data, if FALSE, then the function keeps X and y as is
#' @param lambda_min_ratio Ratio to multiply to lambda_max to define the minimum value of the grid
#' @param lambda_min Minimum value of the grid
#' @param b2_final If TRUE: returns the beta^2 copy instead of the average of the copies for beta. Default is FALSE.
#'
#' @return A list with components:
#'   \describe{
#'     \item{beta}{Estimated regression coefficients corresponding to the oracle-selected parameters (post-estimated if \code{post=TRUE}).}
#'     \item{gamma}{Estimated node parameters (from LA-ADMM) at the oracle-selected parameters. Unchanged by post-estimation.}
#'     \item{lambda1_best}{Selected aggregation penalty (\eqn{\lambda_1}).}
#'     \item{lambda2_best}{Selected sparsity penalty (\eqn{\lambda_2}).}
#'     \item{lambda1}{Grid of lambda1 used for the estimation.}
#'     \item{lambda2}{Grid of lambda2 used for the estimation.}
#'     \item{mse}{Minimum mean squared error achieved.}
#'     \item{iterations}{number of iterations per grid result}
#'   }
#'
#' @export
startime_oracle <- function(X, y, P_list, Ki_list, post = TRUE,
                            true_beta,
                            lambda1_grid = NULL, lambda2_grid = NULL,
                            num_lambdas = 10,
                            rho = 1,
                            K_in = 100, stop_thresh=1e-05,
                            standardize = FALSE,
                            lambda_min_ratio = NULL, lambda_min = NUL,
                            b2_final = FALSE) {

  if (standardize == TRUE){
    # Center the predictors and response
    y <- y - mean(y)
    # Standardize the predictors
    X <- scale(X)
  }

  X <- as.matrix(X)
  y <- as.numeric(y)
  n <- nrow(X)
  p <- ncol(X)
  stopifnot(length(y) == n)
  stopifnot(length(true_beta) == p)

  A <- create_matrix_A(P_list, Ki_list)
  sp_Astar <- create_matrix_A_star(P_list, Ki_list)

  leaf_penalty <- "leaf sparsity"
  node_penalty <- "node sparsity"

  b_init <- rep(0, sum_first_elements(P_list))
  g_init <- rep(0, sum_all_elements(P_list))

  # Auto-generate lambda grids if not provided
  if (is.null(lambda1_grid)) {
    cat("lambda1_grid generated\n")
    lambda1_grid <- lambda_grid(X, y, num_lambdas, penalty = node_penalty, A = A,
                                 sp_Astar = sp_Astar,
                                lambda_min_ratio = lambda_min_ratio,
                                lambda_min = lambda_min)
  }
  if (is.null(lambda2_grid)) {
    cat("lambda2_grid generated\n")
    lambda2_grid <- lambda_grid(X, y, num_lambdas, penalty = leaf_penalty, A = A,
                                 sp_Astar = sp_Astar,
                                lambda_min_ratio = lambda_min_ratio,
                                lambda_min = lambda_min)
  }

  # Run grid solver over lambdas
  beta_grid <- admm_grid(X, y, lambda1_grid, lambda2_grid,
                         rho, K_in,stop_thresh, P_list, Ki_list,
                         b_init,g_init)


  if (post == TRUE) {
    # Post-processing
    post_beta <- post_estimation(X, y, beta_grid, A, P_list)

    # Post MSE selection
    oracle <- mse_rand(post_beta, true_beta)

    beta_best <- post_beta$beta_matrix[, oracle$best_row]
    gamma_best <- beta_grid$gamma_matrix[, oracle$best_row]  # gamma unchanged by post
  } else {
    # Oracle selection on penalized coefficients directly
    oracle <- mse_rand(beta_grid, true_beta)

    if (!beta2_final){
      beta_best <- beta_grid$beta_matrix[, oracle$best_row]
    }
    else {
      beta_best <- beta_grid$beta2_matrix[, oracle$best_row]
    }
    gamma_best <- beta_grid$gamma_matrix[, oracle$best_row]
  }

  return(list(
    beta = beta_best,
    gamma = gamma_best,
    lambda1_best = oracle$best_lambda1,
    lambda2_best = oracle$best_lambda2,
    lambda1 = lambda1_grid,
    lambda2 = lambda2_grid,
    mse = oracle$min_mse,
    iterations = beta_grid$n_iter_matrix
  ))
}

