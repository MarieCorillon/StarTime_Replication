#' Identify Zero Coefficients
#'
#' Finds positions of zero-valued coefficients.
#'
#' @param vec Numeric vector of coefficients
#' @return Indices of zero coefficients
#'
get_zero_id <- function(vec) {
  return(which(vec == 0))
}


#' Filter Non-Zero Groups
#'
#' Identifies groups that contain no zero coefficients.
#'
#' @param group_ids List of coefficient groups
#' @param zero_indices Indices of zero coefficients
#' @return List of non-zero containing groups
#'
get_nz_group_id <- function(group_ids, zero_indices) {
  # Identify the groups that do not contain any zero indices
  nzgroup_id <- lapply(group_ids, function(group) {
    if (length(intersect(group, zero_indices)) == 0) {
      return(group)
    } else {
      return(NULL)
    }
  })

  # Remove NULL elements from the list
  nzgroup_id <- nzgroup_id[!sapply(nzgroup_id, is.null)]

  return(nzgroup_id)
}


#' Zero Group Indicator
#'
#' Creates logical vector indicating groups containing zeros.
#'
#' @param group_ids List of coefficient groups
#' @param zero_indices Indices of zero coefficients
#' @return Logical vector (TRUE = group contains zero)
#'
get_zero_group_indicator <- function(group_ids, zero_indices) {
  # Initialize the indicator vector
  zg <- sapply(group_ids, function(group) {
    # Check if any element of the group is in group_ids (zero indices)
    if (length(intersect(group, zero_indices)) > 0) {
      return(TRUE)  # It's a zero group
    } else {
      return(FALSE)  # It's a non-zero group
    }
  })
  return(zg)
}


#' Expand Group Coefficients to Original Vector
#'
#' Maps group-level coefficients back to original coefficient space.
#'
#' @param group_coefficients Numeric vector of group coefficients
#' @param group_structure List mapping groups to original indices
#' @return Expanded numeric vector
#'
expand_group_coefficients <- function(group_coefficients, group_structure) {
  # Get the total length needed for the final vector
  total_length <- max(unlist(group_structure))

  # Initialize result vector with zeros
  result <- numeric(total_length)

  # For each group, assign its coefficient to all members
  for(i in seq_along(group_structure)) {
    result[group_structure[[i]]] <- group_coefficients[i]
  }

  return(result)
}


#' Gets the Number of Leaves in each Tree
#'
#'
#' @param P_list List containing vectors with the number of nodes on each layer of three (one vector per tree)
#' @return list containing the number of leaves of each tree
#'
get_block_sizes <- function(P_list) {
  sapply(P_list, function(x) x[1])
}


#' Identify Groups in Coefficient Vectors
#'
#' Identifies the positions of coefficients belonging to a same group (that
#' have the same value).
#'
#' @param non_round_vec Numeric vector of coefficients
#' @param P_list List containing vectors with the number of nodes on each layer of three (one vector per tree)
#'
#' @return A list of integer vectors. Each sublist contains indices of
#' elements with the same (rounded to the 10th decimal) value.
get_group_id_blocked <- function(non_round_vec, P_list) {
  block_sizes <- get_block_sizes(P_list)
  groups <- list()
  start_idx <- 1
  for (size in block_sizes) {
    block_indices <- start_idx:(start_idx + size - 1)
    block_vec <- round(non_round_vec[block_indices], 10)
    unique_vals <- unique(block_vec)
    for (val in unique_vals) {
      positions <- which(block_vec == val)
      if (length(positions) > 0) {
        # Adjust positions to absolute indices
        groups <- append(groups, list(block_indices[positions]))
      }
    }
    start_idx <- start_idx + size
  }
  return(groups)
}


#' Post-Estimation of Coefficients via Group-Aggregated OLS
#'
#' Performs a post-estimation step for coefficient vectors from a grid search output,
#' applying ordinary least squares (OLS) on groups of predictors aggregated based
#' on a grouping matrix. Handles zero-coefficient groups by setting their coefficients to zero.
#'
#' @param X Numeric matrix of predictors (observations x features).
#' @param y Numeric response vector.
#' @param grid_output A list output from a grid search procedure from the \code{admm_grid fuction}.
#' @param A Numeric matrix mapping groups to original coefficients.
#' @param P_list List containing vectors with the number of nodes on each layer of three (one vector per tree)
#'
#' @return A list with components:
#' \describe{
#'   \item{\code{beta_matrix}}{Matrix of post-estimated coefficients for each grid combination (features x grid combinations).}
#'   \item{\code{lambda_indices}}{Lambda indices from the input \code{grid_output}.}
#' }
#'
#' @details
#' The function loops over all combinations in the grid search output, computes group-level coefficients,
#' identifies zero and non-zero coefficient groups, and performs OLS regression on the predictors aggregated by non-zero groups.
#' Groups identified as zero are assigned zero coefficients in the final output.
#' If OLS cannot be performed (e.g., if the number of aggregated predictors exceeds number of observations), it returns \code{NA} coefficients.
#'
#' @export
post_estimation <- function(X, y, grid_output, A, P_list) {

  ncomb <- ncol(grid_output$beta1_matrix)
  ncoefs <- ncol(X)
  postols_matrix <- matrix(0, nrow = ncoefs, ncol = ncomb)
  convergence=TRUE

  # Loop through each combination in grid_output
  for (i in 1:ncomb) {
    # Extract group_beta and sparsity_beta for the current lambda1-lambda2
    group_beta <- A %*% grid_output$gamma1_matrix[,i]
    sparsity_beta <- grid_output$beta2_matrix[,i]

    # Get group and zero indices
    gid <- get_group_id_blocked(group_beta, P_list)
    sid <- get_zero_id(sparsity_beta)
    nzid <- get_nz_group_id(gid, sid)

    if (length(sid) == length(sparsity_beta) || (length(gid) == 1 && length(sid) != 0 || length(nzid)==0)){
      postols <- rep(0,ncoefs)
    } else {
      zg <- get_zero_group_indicator(gid, sid)
      nzid <- gid[!zg]
      # Aggregate X based on non-zero groups
      Xaggrnz <- sapply(nzid, function(indices) rowSums(X[, indices, drop = FALSE]))

      if (ncol(Xaggrnz)>=nrow(Xaggrnz)){

        postols <- rep(NA,ncoefs)

      }
      else {

        # Run post-OLS on the aggregated non-zero group data
        postOLS <- ols(Xaggrnz, y)

        # Prepare the final group coefficients (set 0 for zero groups)
        groups_zero <- numeric(length(gid))

        groups_zero[!zg] <- postOLS
        postols <- expand_group_coefficients(groups_zero, gid)

      }


    }

    postols_matrix[,i] <- postols
  }

  return(list(beta_matrix = postols_matrix,
              lambda_indices = grid_output$lambda_indices
  ))
}



#' Ordinary Least Squares (OLS) Estimator
#'
#' Computes the OLS solution for the linear model \eqn{y = X\beta + \epsilon}.
#'
#' @param X A numeric matrix of predictors (n x p), where n is the number of observations and p is the number of predictors.
#' @param y A numeric vector of responses (length n).
#'
#' @return A numeric vector of estimated coefficients (length p).
#'
#' @export
ols <- function(X,y){
  # if (dim(X)[1] < dim(X)[2]){
  #   sol <- NA
  # } else {
  sol <- solve(t(X)%*%X)%*%t(X)%*%y
  # }
  return(sol)
}

