#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;
using namespace arma;
// [[Rcpp::depends(RcppArmadillo)]]



//' Sum First Elements of Each Vector in a List
 //'
 //' Computes the sum of the first element of each numeric vector in a list.
 //'
 //' @param vec_list A list of numeric vectors.
 //' @return A double, the sum of the first elements of each vector.
 //' @examples
 //' sum_first_elements(list(c(1,2), c(3,4)))
 // [[Rcpp::export]]
 double sum_first_elements(List vec_list) {
   double firsts = 0.0;

   // Loop over each element in the list
   for (R_xlen_t i = 0; i < vec_list.size(); i++) {
     NumericVector vec = vec_list[i]; // Access the i-th vector
     if (vec.size() > 0) {           // Check if the vector is not empty
       firsts += vec[0];                  // Add the first element to N
     }
   }

   return firsts; // Return the sum
 }



 //' Sum All Elements in a List of Vectors
 //'
 //' Computes the sum of all elements in all numeric vectors in a list.
 //'
 //' @param vec_list A list of numeric vectors.
 //' @return A double, the sum of all elements.
 //' @examples
 //' sum_all_elements(list(c(1,2), c(3,4)))
 // [[Rcpp::export]]
 double sum_all_elements(List vec_list) {
   double allsum = 0.0;

   // Loop over each element in the list
   for (R_xlen_t i = 0; i < vec_list.size(); i++) {
     NumericVector vec = vec_list[i]; // Access the i-th vector
     if (vec.size() > 0) {           // Check if the vector is not empty
       allsum += std::accumulate(vec.begin(), vec.end(), 0.0); // Add all elements of the vector
     }
   }

   return allsum; // Return the sum
 }


 //' Access an Element from a List of Vectors
 //'
 //' Returns the value at a specified position in a specified vector within a list.
 //'
 //' @param list_of_vectors A list of numeric vectors.
 //' @param vector_index The index of the vector in the list (0-based).
 //' @param element_index The index of the element in the vector (0-based).
 //' @return The value at the specified position.
 //' @examples
 //' access_list(list(c(1,2), c(3,4)), 1, 0) # returns 3
 // [[Rcpp::export]]
 double access_list(List list_of_vectors, int vector_index, int element_index) {
   // Access the vector at the specified index
   NumericVector vec = list_of_vectors[vector_index];
   // Access the specific element in the vector
   return vec[element_index];
 }



 //' Maximum Length of Vectors in a List
 //'
 //' Returns the maximum length among all numeric vectors in a list.
 //'
 //' @param list_of_vectors A list of numeric vectors.
 //' @return An integer, the maximum vector length.
 //' @examples
 //' max_vec_length(list(c(1,2), c(3,4,5)))
 // [[Rcpp::export]]
 R_xlen_t max_vec_length(List list_of_vectors) {
   R_xlen_t max_length = 0; // Initialize the maximum length to 0

   for (R_xlen_t i = 0; i < list_of_vectors.size(); ++i) {
     arma::vec vec = as<arma::vec>(list_of_vectors[i]); // Convert each list element to an Armadillo vector
     R_xlen_t vec_length = vec.n_elem;                      // Get the size of the Armadillo vector
     if (vec_length > max_length) {                    // Update max_length if necessary
       max_length = vec_length;
     }
   }

   return max_length; // Return the maximum length
 }



 //' Create Matrix A for Hierarchical Structure (Tree Encoding)
 //'
 //' Constructs a block matrix representing hierarchical relationships based on
 //' input lists (tree encoding)
 //'
 //' @param P_list A list of vectors specifying number of nodes at each level.
 //' @param Ki_list  A list of vectors specifying group sizes at each level.
 //' @return A numeric matrix representing the hierarchical structure.
 //' @importClassesFrom Matrix dgCMatrix
 //' @examples
 //' create_matrix_A(list(c(20, 4, 1)), list(c(5, 4, 1)))
 // [[Rcpp::export]]
 arma::mat create_matrix_A(List P_list, List Ki_list) {
   int N;
   N = sum_first_elements(P_list);

   int total_nodes;
   total_nodes=sum_all_elements(P_list);

   int L = max_vec_length(P_list);

   arma::mat A = arma::zeros<arma::mat>(N, total_nodes);
   A.submat(0, 0, N-1, N-1) = arma::eye<arma::mat>(N, N); // The first pxp is the identiy matrix


   if (L > 1){ // if we have less than 2 levels, then we only need the identity matrix
     int totTree = P_list.size(); // total number of trees

     arma::vec levelnodes(totTree, arma::fill::ones); // vector that contains the first value of the Ki vectors
     for (int i = 0; i < totTree; ++i) {
       // Access the i-th vector and its first element
       NumericVector vec = Ki_list[i];
       levelnodes(i) = vec[0]; // Assign the first element to levelnodes
     }


     for (int level = 0; level < L; level ++){
       int init = 0;

       for (R_xlen_t tree = 0; tree < totTree; tree++) {
         // Get the length of the vector at position "tree" in P_list
         Rcpp::NumericVector p_vec = P_list[tree];
         int vec_length = p_vec.size();

         if ((vec_length-1) <= level) {
           init += access_list(P_list, tree, 0); // If the tree has less levels than maxlevel, then we skip the rows corresponding to its leaves
           continue;
         }

         else {
           // Update `N` and `levelnodes(tree)` for the next iteration
           for (int j = 0; j < access_list(P_list, tree, level + 1); j++) {
             A.submat(init, (N + j), (init + levelnodes(tree) - 1), (N + j)).fill(1);
             init += levelnodes(tree);
           }
           N += access_list(P_list, tree, level + 1);
           levelnodes(tree) *= access_list(Ki_list, tree, level + 1);
         }
       }
     }
   }


   return A;
 }





 //' Create Sparse Matrix A for Hierarchical Structure (Tree Encoding)
 //'
 //' Constructs a sparse block matrix representing hierarchical relationships based on input lists.
 //'
 //' @param P_list A list of vectors specifying number of nodes at each level.
 //' @param Ki_list  A list of vectors specifying group sizes at each level.
 //' @return A sparse matrix (arma::sp_mat), compatible with the 'Matrix' package.
 //' @importClassesFrom Matrix dgCMatrix
 //' @examples
 //' create_sparse_matrix_A(list(c(20, 4, 1)), list(c(5, 4, 1)))
 // [[Rcpp::export]]
 arma::sp_mat create_sparse_matrix_A(List P_list, List Ki_list) {
   int N;
   N = sum_first_elements(P_list);

   int total_nodes;
   total_nodes=sum_all_elements(P_list);

   int L = max_vec_length(P_list);

   arma::mat A = arma::zeros<arma::mat>(N, total_nodes);
   A.submat(0, 0, N-1, N-1) = arma::eye<arma::mat>(N, N); // The first pxp is the identiy matrix


   if (L > 1){ // if we have less than 2 levels, then we only need the identity matrix
     int totTree = P_list.size(); // total number of trees

     arma::vec levelnodes(totTree, arma::fill::ones); // vector that contains the first value of the Ki vectors
     for (R_xlen_t i = 0; i < totTree; ++i) {
       // Access the i-th vector and its first element
       NumericVector vec = Ki_list[i];
       levelnodes(i) = vec[0]; // Assign the first element to levelnodes
     }


     // for (int level = 0; level < L-1; level ++){
     for (int level = 0; level < L; level ++){
       int init = 0;

       for (int tree = 0; tree < totTree; tree++) {
         // Get the length of the vector at position "tree" in P_list
         int vec_length = Rcpp::as<NumericVector>(P_list[tree]).size();

         if ((vec_length-1) <= level) {
           init += access_list(P_list, tree, 0); // If the tree has less levels than maxlevel, then we skip the rows corresponding to its leaves
           continue;
         }

         else {
           // Update `N` and `levelnodes(tree)` for the next iteration
           for (R_xlen_t j = 0; j < access_list(P_list, tree, level + 1); j++) {
             A.submat(init, (N + j), (init + levelnodes(tree) - 1), (N + j)).fill(1);
             init += levelnodes(tree);
           }
           N += access_list(P_list, tree, level + 1);
           levelnodes(tree) *= access_list(Ki_list, tree, level + 1);
         }
       }
     }
   }

   // Convert the dense matrix to a sparse matrix
   arma::sp_mat sparse_A(A);

   return sparse_A;
 }




 //' Create Extended Hierarchical Matrix A*
 //'
 //' Constructs an extended sparse matrix for hierarchical relationships, stacking layers.
 //'
 //' @param P_list A list of vectors specifying group sizes at each level.
 //' @param Ki_list A list of vectors specifying number of children at each level.
 //' @return A sparse matrix representing the extended hierarchy.
 //' @importClassesFrom Matrix dgCMatrix
 //' @examples
 //' create_matrix_A_star(list(c(20, 4, 1)), list(c(5, 4, 1)))
 // [[Rcpp::export]]
 arma::sp_mat create_matrix_A_star(List P_list, List Ki_list) {
   // Calculate dimensions
   size_t total_nodes = sum_all_elements(P_list);  // Assuming this helper function exists
   R_xlen_t L = max_vec_length(P_list);             // Assuming this helper function exists
   size_t sum_P = sum_first_elements(P_list);     // Assuming this helper function exists

   // Create initial matrix
   sp_mat A_star = create_sparse_matrix_A(P_list, Ki_list);  // Assuming this function exists

   // Iterate through layers
   for (R_xlen_t i = 1; i < L; ++i) {  // Note: Using 1-based indexing to match R

     // Create sublists starting from the ith entry of each vector
     List P_list_sub;
     List Ki_list_sub;

     for (R_xlen_t j = 0; j < P_list.length(); ++j) {
       arma::vec P_vec = as<arma::vec>(P_list[j]);
       arma::vec Ki_vec = as<arma::vec>(Ki_list[j]);

       if (P_vec.n_elem >= i + 1) {  // Adding 1 to i for 1-based indexing
         P_list_sub.push_back(P_vec.subvec(i, P_vec.n_elem - 1));
       }
       if (Ki_vec.n_elem >= i + 1) {
         Ki_list_sub.push_back(Ki_vec.subvec(i, Ki_vec.n_elem - 1));
       }
     }

     // Create temporary matrix for this layer
     sp_mat A_temp = create_sparse_matrix_A(P_list_sub, Ki_list_sub);
     size_t sub_sum_P = sum_first_elements(P_list_sub);

     // Create and combine matrices
     sp_mat zeros_mat(sub_sum_P, sum_P);  // Sparse matrix automatically initialized to zeros
     A_temp = join_horiz(zeros_mat, A_temp);
     A_star = join_vert(A_star, A_temp);

     sum_P += sub_sum_P;
   }

   // Verify dimensions
   if (A_star.n_rows != total_nodes || A_star.n_cols != total_nodes) {
     stop("A* should have as many rows and columns as nodes in the tree.");
   }

   return A_star;
 }




 //' Compute Null Space of Augmented Matrix
 //'
 //' Computes the null space of the matrix (I : -A), where A is a sparse matrix.
 //'
 //' @param A A sparse matrix.
 //' @return A matrix whose columns form a basis for the null space.
 // [[Rcpp::export]]
 arma::mat updateb3g2 (const arma::sp_mat& A) {
   // Compute the null space of (I:-A)
   int N = A.n_rows;

   // (I : -A)
   arma::mat IA(join_rows(arma::speye(N, N), -A));
   arma::mat nullIA = null(IA);
   return nullIA;
 }



 //' Ridge Regularized Least Squares Solution
 //'
 //' Computes the ridge solution for a given matrix using SVD.
 //'
 //' @param X A numeric matrix.
 //' @param rho Regularization parameter.
 //' @return The ridge solution matrix.
 // [[Rcpp::export]]
 arma::mat updateb1 (const arma::mat& X, double rho) {
   int T = X.n_rows;
   int N = X.n_cols;
   arma::mat U;
   arma::vec s;
   arma::mat V;
   svd_econ(U, s, V, X); // Perform the economic SVD on matrix A

   arma::mat VComp;

   if (T < N) {
     arma::mat diagComp = diagmat(1 / (square(s) + T * rho));
     arma::mat outerComp = arma::eye(N, N) - V * V.t();
     VComp = V * diagComp * V.t() + outerComp / (T * rho);
   } else {
     arma::mat diagComp = diagmat(1 / (square(s) + T * rho));
     VComp = V * diagComp * V.t();
   }

   // // Validation checks
   // arma::mat XtX = X.t() * X;
   // arma::mat ridge_mat = XtX + n * rho * arma::eye(N,N);
   // arma::mat should_be_eye = ridge_mat * VComp;
   //
   // // Print or log info
   // Rcpp::Rcout << "Singular values min: " << s.min() << ", max: " << s.max() << "\n";
   //   Rcpp::Rcout << "Condition number of X: " << s.max()/ s.min() << "\n";
   //   Rcpp::Rcout << "Max deviation from I in ridge_mat * VComp: " << arma::abs(should_be_eye - arma::eye(N,N)).max() << "\n";


   return VComp;
 }



 //' Soft Thresholding Operator with Loadings
 //'
 //' Applies the soft-thresholding operator elementwise to a numeric vector,
 //' allowing for individual loadings (scaling factors) per element.
 //' Each entry is shrunk towards zero by `lambda * loads[i]`; if the absolute
 //' value is less than or equal to this threshold, it is set to zero.
 //'
 //' @param x A numeric vector to be thresholded.
 //' @param lambda A non-negative threshold parameter.
 //' @param loads A numeric vector of positive loadings (same length as x), scaling the threshold for each element.
 //' @return A numeric vector of the same length as x, after soft thresholding.
 // [[Rcpp::export]]
 arma::vec soft_threshold(const arma::vec& x, double lambda) {
   arma::vec result = x;
   for (arma::uword i = 0; i < x.n_elem; ++i) {
     if (std::abs(x[i]) > lambda) {
       result[i] = std::copysign(std::abs(x[i]) - (lambda), x[i]);
     } else {
       result[i] = 0.0;
     }
   }
   return result;
 }



 //' ADMM Solver for Sparse Tree-Aggregation Regression
 //'
 //' Solves a penalized regression problem with sparsity and aggregation
 //' penalties using ADMM.
 //'
 //' @param X Numeric matrix of predictors.
 //' @param y Numeric response vector.
 //' @param lambda1 Aggregation (node) penalty parameter.
 //' @param lambda2 Sparsity (leaf) penalty parameter.
 //' @param rho ADMM penalty parameter.
 //' @param K_in Number of ADMM iterations.
 //' @param stop_thresh Threshold to stop the iterations once convergence gas been achieved (depends on the scae of the data)
 //' @param P_list List specifying number of nodes at each level.
 //' @param Ki_list List specifying group sizes at each level.
 //' @param leaf_penalty Type of leaf penalty ("leaf sparsity", "leaf hierarchy").
 //' @param node_penalty Type of node penalty ("node sparsity", "node hierarchy", "node descendant").
 //' @param b_init Initial value for beta.
 //' @param g_init Initial value for gamma.
 //' @return List of results including coefficients, dual variables, and iteration history.
 // [[Rcpp::export]]
 Rcpp::List admm_solver(const arma::mat& X, const arma::vec& y,
                        const double lambda1, const double lambda2, double rho,
                        int K_in,
                        const double stop_thresh,
                        List P_list, List Ki_list,
                        arma::vec& b_init,arma::vec& g_init) { // With warm start (take the beta and gamma from the previous lambda as a start)
   int T = X.n_rows;
   int N = sum_first_elements(P_list);
   arma::vec Xty = X.t() * y;
   arma::mat VComp = updateb1(X,rho);
   int M = sum_all_elements(P_list);
   arma::sp_mat A = create_sparse_matrix_A(P_list,Ki_list);
   arma::mat nullIA = updateb3g2(A);
   arma::vec b = b_init;
   arma::vec g = g_init;

   arma::vec v1 = arma::zeros<arma::vec>(N);
   arma::vec v2 = arma::zeros<arma::vec>(N);
   arma::vec v3 = arma::zeros<arma::vec>(N);
   arma::vec u1 = arma::zeros<arma::vec>(M);
   arma::vec u2 = arma::zeros<arma::vec>(M);


   // Form the groups for each penalty
   arma::sp_mat Astar = create_matrix_A_star(P_list, Ki_list);

   int iter = 0;
   arma::vec b1 = arma::zeros<arma::vec>(N);
   arma::vec b2 = arma::zeros<arma::vec>(N);
   arma::vec b3 = arma::zeros<arma::vec>(N);
   arma::vec g1 = arma::zeros<arma::vec>(M);
   arma::vec g2 = arma::zeros<arma::vec>(M);


   // Containers to store values at each iteration
   arma::mat b_store(N, K_in);
   arma::mat g_store(M, K_in);
   arma::mat v1_store(N, K_in);
   arma::mat v2_store(N, K_in);
   arma::mat v3_store(N, K_in);
   arma::mat u1_store(M, K_in);
   arma::mat u2_store(M, K_in);
   arma::mat b1_store(N, K_in);
   arma::mat b2_store(N, K_in);
   arma::mat b3_store(N, K_in);
   arma::mat g1_store(M, K_in);
   arma::mat g2_store(M, K_in);

   arma::vec b_prev = b;     // for convergence check


   for (iter=0;iter < K_in;iter++) {
     // save previous b
     b_prev = b;

     arma::vec temp1 = Xty + T * rho * b - T * v1;
     b1 = VComp * temp1;
     b2 = soft_threshold(b - (v2 / rho), (lambda2/rho));

     g1 = soft_threshold(g - (u1 / rho), (lambda1/rho));

     arma::vec temp2 = arma::join_cols((b - v3 / rho), (g - u2 / rho));
     arma::vec b3g2 = nullIA * (nullIA.t() * temp2);
     b3 = b3g2.subvec(0, N - 1);
     g2 = b3g2.subvec(N, N+ M - 1);

     // Rcpp::Rcout << "b3: " << b3.t();
     // Rcpp::Rcout << "g2: " << g2.t();

     b = (b1 + b2 + b3) / 3.0;
     v1 += rho * (b1 - b);
     v2 += rho * (b2 - b);
     v3 += rho * (b3 - b);

     g = (g1 + g2) / 2.0;
     u1 += rho * (g1 - g);
     u2 += rho * (g2 - g);


     // Store values for the current iteration
     b_store.col(iter) = b;
     g_store.col(iter) = g;
     b1_store.col(iter) = b1;
     b2_store.col(iter) = b2;
     b3_store.col(iter) = b3;
     g1_store.col(iter) = g1;
     g2_store.col(iter) = g2;
     v1_store.col(iter) = v1;
     v2_store.col(iter) = v2;
     v3_store.col(iter) = v3;
     u1_store.col(iter) = u1;
     u2_store.col(iter) = u2;

     // convergence on b: max absolute change
     double max_abs_diff_b = arma::abs(b - b_prev).max();
     if (max_abs_diff_b < stop_thresh) {
       iter++;
       break;
     }

   }

   // Shrink stores to actual number of iterations used
   if (iter < K_in) {
     b_store  = b_store.cols(0, iter - 1);
     g_store  = g_store.cols(0, iter - 1);
     b1_store = b1_store.cols(0, iter - 1);
     b2_store = b2_store.cols(0, iter - 1);
     b3_store = b3_store.cols(0, iter - 1);
     g1_store = g1_store.cols(0, iter - 1);
     g2_store = g2_store.cols(0, iter - 1);
     v1_store = v1_store.cols(0, iter - 1);
     v2_store = v2_store.cols(0, iter - 1);
     v3_store = v3_store.cols(0, iter - 1);
     u1_store = u1_store.cols(0, iter - 1);
     u2_store = u2_store.cols(0, iter - 1);
   }

   return Rcpp::List::create(Rcpp::Named("beta") = b, Rcpp::Named("gamma") = g,
                             Rcpp::Named("beta1") = b1,
                             Rcpp::Named("beta2") = b2,
                             Rcpp::Named("beta3") = b3,
                             Rcpp::Named("gamma1") = g1,
                             Rcpp::Named("gamma2") = g2,
                             Rcpp::Named("b_store") = b_store,
                             Rcpp::Named("g_store") = g_store,
                             Rcpp::Named("b1_store") = b1_store,
                             Rcpp::Named("b2_store") = b2_store,
                             Rcpp::Named("b3_store") = b3_store,
                             Rcpp::Named("g1_store") = g1_store,
                             Rcpp::Named("g2_store") = g2_store,
                             Rcpp::Named("v1_store") = v1_store,
                             Rcpp::Named("v2_store") = v2_store,
                             Rcpp::Named("v3_store") = v3_store,
                             Rcpp::Named("u1_store") = u1_store,
                             Rcpp::Named("u2_store") = u2_store,
                             Rcpp::Named("n_iter")   = iter);  // return actual iterations
 }


 //' Run ADMM Over a Grid of Penalty Parameters (Final Values Only)
 //'
 //' @param X Numeric matrix of predictors.
 //' @param y Numeric response vector.
 //' @param lambda1_grid Grid of values of ggregation (node) penalty parameters.
 //' @param lambda2_grid Grid of values of sparsity (leaf) penalty parameters.
 //' @param rho Value for the ADMM penalty parameter.
 //' @param K_in Number of ADMM iterations.
 //' @param stop_thresh Threshold to stop the iterations once convergence gas been achieved (depends on the scae of the data)
 //' @param P_list List specifying number of nodes at each level.
 //' @param Ki_list List specifying group sizes at each level.
 //' @param b_init Initial value for beta coefficients.
 //' @param g_init Initial value for gamma coefficients.
 //' @return A list containing matrices of beta and gamma values for each grid point and the lambda grids and indices.
 // [[Rcpp::export]]
 Rcpp::List admm_grid(const arma::mat& X, const arma::vec& y,
                      const arma::vec& lambda1_grid,
                      const arma::vec& lambda2_grid, double rho, int K_in,
                      const double stop_thresh,
                      List P_list, List Ki_list,
                      arma::vec& b_init,
                      arma::vec& g_init) {

   int n_lambda1 = lambda1_grid.n_elem;
   int n_lambda2 = lambda2_grid.n_elem;

   // Matrix to store the final beta and gamma vectors for each lambda1 and lambda2 combination
   arma::mat beta_matrix(b_init.n_elem, n_lambda1 * n_lambda2);
   arma::mat gamma_matrix(g_init.n_elem, n_lambda1 * n_lambda2);
   arma::mat beta1_matrix(b_init.n_elem, n_lambda1 * n_lambda2);
   arma::mat beta2_matrix(b_init.n_elem, n_lambda1 * n_lambda2);
   arma::mat beta3_matrix(b_init.n_elem, n_lambda1 * n_lambda2);
   arma::mat gamma1_matrix(g_init.n_elem, n_lambda1 * n_lambda2);
   arma::mat gamma2_matrix(g_init.n_elem, n_lambda1 * n_lambda2);

   // Vector to store the number of iterations for each combination
   arma::vec n_iter_vector(n_lambda1 * n_lambda2);

   // Matrix to store the indices of lambda1 and lambda2 for each column in beta_matrix and gamma_matrix
   arma::mat lambda_indices(n_lambda1 * n_lambda2, 2);

   int index = 0;

   for (int j = 0; j < n_lambda2; ++j) {
     for (int i = 0; i < n_lambda1; ++i) {
       double lambda1 = lambda1_grid[i];
       double lambda2 = lambda2_grid[j];

       // Store the current indices for lambda1 and lambda2
       lambda_indices(index, 0) = lambda1; // Store lambda1 value
       lambda_indices(index, 1) = lambda2; // Store lambda2 value

       // Compute admm for the current combination of lambda1 and lambda2
       Rcpp::List results = admm_solver(X, y,lambda1, lambda2, rho,
                                        K_in,stop_thresh,P_list, Ki_list,
                                        b_init,g_init);

       // Store the final beta and gamma values in their respective matrices
       arma::vec beta_final  = Rcpp::as<arma::vec>(results["beta"]);
       arma::vec gamma_final = Rcpp::as<arma::vec>(results["gamma"]);
       arma::vec beta1_final = Rcpp::as<arma::vec>(results["beta1"]);
       arma::vec beta2_final = Rcpp::as<arma::vec>(results["beta2"]);
       arma::vec beta3_final = Rcpp::as<arma::vec>(results["beta3"]);
       arma::vec gamma1_final = Rcpp::as<arma::vec>(results["gamma1"]);
       arma::vec gamma2_final = Rcpp::as<arma::vec>(results["gamma2"]);
       int n_iter = Rcpp::as<int>(results["n_iter"]);

       beta_matrix.col(index) = beta_final;
       gamma_matrix.col(index) = gamma_final;
       beta1_matrix.col(index) = beta1_final;
       beta2_matrix.col(index) = beta2_final;
       beta3_matrix.col(index) = beta3_final;
       gamma1_matrix.col(index) = gamma1_final;
       gamma2_matrix.col(index) = gamma2_final;
       n_iter_vector(index) = n_iter;

       index++;
     }
   }

   return Rcpp::List::create(Rcpp::Named("beta_matrix") = beta_matrix,
                             Rcpp::Named("gamma_matrix") = gamma_matrix,
                             Rcpp::Named("beta1_matrix") = beta1_matrix,
                             Rcpp::Named("beta2_matrix") = beta2_matrix,
                             Rcpp::Named("beta3_matrix") = beta3_matrix,
                             Rcpp::Named("gamma1_matrix") = gamma1_matrix,
                             Rcpp::Named("gamma2_matrix") = gamma2_matrix,
                             Rcpp::Named("lambda_indices") = lambda_indices,
                             Rcpp::Named("n_iter_matrix") = n_iter_vector);
 }
