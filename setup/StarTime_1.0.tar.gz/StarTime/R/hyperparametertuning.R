lambda_grid <- function(X,y, num_lambdas,penalty,A = NULL,
                        sp_Astar = NULL, lambda_min_ratio = NULL,
                        lambda_min = NULL) {
  #
  # if (standardize == TRUE){
  #   # Center the predictors and response
  #   y <- y - mean(y)
  #   # Standardize the predictors
  #   X <- scale(X)
  # }
  #

  if (penalty == "node sparsity"){
    lambda_max <- max(abs(t(X%*%A) %*% y)) / nrow(X)
  }

  else if (penalty == "leaf sparsity"){
    lambda_max <- max(abs(t(X) %*% y)) / nrow(X)
  }

  # Define lambda min ratio based on the data dimensions if not provided
  if (is.null(lambda_min_ratio)) {
    lambda_min_ratio <- ifelse(nrow(X) > ncol(X), 1e-4, 1e-7)
  }

  if (is.null(lambda_min)){
    # Define lambda min as a fraction of lambda max
    lambda_min <- lambda_max * lambda_min_ratio
  } else {
    lambda_min = lambda_min
  }

  # Generate the lambda sequence on a logarithmic scale
  lambda_sequence <- exp(seq(log(lambda_max), log(lambda_min), length = num_lambdas))

  return(lambda_sequence)
}



# Performs time series cross validation
ts_cv <- function(X,y, split = 0.8, step_size = 1, lambda1_range, lambda2_range,
                  rho, K_in, P_list, Ki_list,b_init,g_init) {

  # Calculate the initial window size
  n <- nrow(X)
  A <- create_matrix_A(P_list, K_list)
  window_size <- floor(n * split)

  forecast_errors <- matrix(NA,
                            nrow = length(seq(window_size, n-1, by = step_size)),
                            ncol = length(lambda1_range)*length(lambda2_range))

  # Counter for storing results
  counter <- 1

  # Loop through the data using rolling window
  for(i in seq(1, n - window_size, by = step_size)) {
    # Define training window indices
    train_end <- i + window_size - 1
    test_point <- train_end + 1

    # Get training data
    train_X <- X[i:train_end,]
    train_y <- y[i:train_end]

    beta_grid_train <- admm_grid(train_X, train_y, lambda1_range, lambda2_range,
                                 rho, K_in,stop_thresh, P_list, Ki_list,
                                 b_init,g_init)

    post_train <- post_estimation(train_X,train_y,beta_grid_train,A,P_list)

    # Get test point features
    test_X <- X[test_point,]

    # Calculate forecasts for all parameter combinations at once
    forecasts <- drop(test_X %*% post_train$beta_matrix)

    # Store squared forecast errors for all combinations
    forecast_errors[counter, ] <- (y[test_point] - forecasts)^2

    counter <- counter + 1

    print(i)
  }

  # Calculate MSFE for each parameter combination
  msfe <- colMeans(forecast_errors, na.rm = TRUE)

  # Find optimal combination
  best_row <- which.min(msfe)
  optimal_combination <- post_train$lambda_indices[best_row,]


  # Create results list
  return(list(
    msfe = msfe,
    best_lambda1 = optimal_combination[1],
    best_lambda2 = optimal_combination[2],
    best_row = best_row
  ))
}





# Computes different sorts of information criteria for model selection
ic_deriv <- function(X, y, b, beta_group,beta_sparse, ic_type = "BIC", thresh){
  n <- nrow(X) # Number of observations
  p <-  length(unique(beta_group[beta_sparse != 0])) # Unique non zero estimated coefficients
  resid <- y-X%*%b
  ssr <- sum(resid^2)/n

  if (ic_type == "AIC"){
    CT <- 2
  } else if (ic_type ==  "BIC"){
    CT <- log(n)
  } else if (ic_type == "EBIC"){
    g=0.5
    CT <-  log(n) + 2*g*log(length(b))
  }

  if (p/n < thresh){
    ic <- log(ssr)+(p/n)*CT
  } else {
    ic <- Inf
  }

  return(ic)

}



# Function that selects the best hyperparameters by choosing the lambda1-lambda2
# combination with the smallest information criterion
ic_select_apply <- function(X, y, A, grid_output, ic_type = "BIC", thresh) {

  beta_matrix <- grid_output$beta_matrix
  gamma1_matrix <- grid_output$gamma1_matrix
  beta2_matrix <- grid_output$beta2_matrix
  lambda_indices <- grid_output$lambda_indices

  ic_values <- sapply(1:ncol(beta_matrix), function(i) {
    b <- beta_matrix[, i]
    gamma1 <- gamma1_matrix[, i]
    groupbeta <- A %*% gamma1
    sparsebeta <- beta2_matrix[,i]
    ic_deriv(X, y, b, groupbeta,sparsebeta, ic_type = ic_type, thresh=thresh)
  })

  min_ic_index <- which.min(ic_values)

  best_lambda1 <- lambda_indices[min_ic_index, 1]
  best_lambda2 <- lambda_indices[min_ic_index, 2]

  lambda1_index <- which(grid_output$lambda_indices[, 1] == best_lambda1)
  lambda2_index <- which(grid_output$lambda_indices[, 2] == best_lambda2)

  return(list(
    best_lambda1 = best_lambda1,
    best_lambda2 = best_lambda2,
    lambda1_index = lambda1_index,
    lambda2_index = lambda2_index,
    min_ic = ic_values[min_ic_index],
    values = ic_values
  ))
}



# IC selection for the post estimation (so the groups and sparsity is already included)
ic_select_post <- function(X, y, grid_output, ic_type = "BIC", thresh) {

  beta_matrix <- grid_output$beta_matrix
  lambda_indices <- grid_output$lambda_indices

  ic_values <- sapply(1:ncol(beta_matrix), function(i) {
    b <- beta_matrix[, i]
    ic_deriv(X, y, b, b,b, ic_type = ic_type, thresh=thresh)
  })

  min_ic_index <- which.min(ic_values)

  best_lambda1 <- lambda_indices[min_ic_index, 1]
  best_lambda2 <- lambda_indices[min_ic_index, 2]

  lambda1_index <- which(grid_output$lambda_indices[, 1] == best_lambda1)
  lambda2_index <- which(grid_output$lambda_indices[, 2] == best_lambda2)

  best_row <- which((grid_output$lambda_indices[,1] == best_lambda1) &
                      (grid_output$lambda_indices[,2] == best_lambda2))

  return(list(
    best_lambda1 = best_lambda1,
    best_lambda2 = best_lambda2,
    lambda1_index = lambda1_index,
    lambda2_index = lambda2_index,
    min_ic = ic_values[min_ic_index],
    values = ic_values,
    best_row = best_row
  ))
}



compute_mse <- function(beta_estimated, true_beta) {
  mean((beta_estimated - true_beta)^2)
}



mse_rand <- function(grid_output, true_beta) {

  beta_matrix <- grid_output$beta_matrix
  lambda_indices <- grid_output$lambda_indices

  mse_values <- apply(beta_matrix, 2, function(estim) {
    compute_mse(beta_estimated = estim, true_beta)
  })

  min_mse_index <- which.min(mse_values)

  best_lambda1 <- lambda_indices[min_mse_index, 1]
  best_lambda2 <- lambda_indices[min_mse_index, 2]

  lambda1_index <- which(grid_output$lambda_indices[, 1] == best_lambda1)
  lambda2_index <- which(grid_output$lambda_indices[, 2] == best_lambda2)

  best_row <- which((grid_output$lambda_indices[,1] == best_lambda1) &
                      (grid_output$lambda_indices[,2] == best_lambda2))

  return(list(
    best_lambda1 = best_lambda1,
    best_lambda2 = best_lambda2,
    lambda1_index = lambda1_index,
    lambda2_index = lambda2_index,
    min_mse = mse_values[min_mse_index],
    mse_values = mse_values,
    best_row = best_row
  ))
}
